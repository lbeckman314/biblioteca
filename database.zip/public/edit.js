/*
liam beckman
06 may 2018
dom and events
*/


// wait until the DOM before starting buttons
document.addEventListener('DOMContentLoaded', bindButtons);

function bindButtons(){
    let hiddens = document.getElementsByClassName('hidden');
    let buttonsDelete = document.getElementsByClassName('buttonDelete');
console.log("delete buttons:", buttonsDelete);

    for (let i = 0; i < buttonsDelete.length; i++) {
        buttonsDelete[i].addEventListener('click', function(event){;
            event.preventDefault();
            var req = new XMLHttpRequest();

            req.open('GET', '/delete?id=' + hiddens[i].value, true);
            req.onload = function() {
                let res = req.responseText;
                update();
            }

            req.send(null);
        });
    }
}


function update() {
    var req = new XMLHttpRequest();
    req.open('GET', '/update', true);
    req.onload = function() {
        let res = req.responseText;
        document.getElementById('results').innerHTML = res;
        
        // create table and selection
        let oldTable = document.getElementById("myTable");
        document.querySelector("#table").replaceChild(tabler(), oldTable);
        bindButtons();
        insert();
    }
    req.send(null);
}

function insert() {
    let formInsert = document.createElement("form");
    //formInsert.action = "https://liambeckman.com/code/webdev/getpost";
    formInsert.action = "/insert";
    formInsert.method = "get";

    let fieldset = document.createElement("fieldset");
    formInsert.appendChild(fieldset);

    let legend = document.createElement("legend");
    fieldset.appendChild(legend);
    legend.innerHTML = "add";

    for (let i = 0; i < 5; i++) {
        let label = document.createElement("label");
        fieldset.appendChild(label);

        let input = document.createElement("input");
        input.size=20;
        input.maxlength=50;
        
        let textSpan = document.createElement("span");
        textSpan.className = "name";
        label.appendChild(textSpan);


        let decSpan = document.createElement("span");
        decSpan.innerHTML = " ⇢ ";
        decSpan.textContent = " ⇢ ";
        label.appendChild(decSpan);

        switch (i) {
            case 0:
                textSpan.textContent = "name";
                input.name="name";
                input.placeholder="Obi-Wan";
                input.type="text_input";
                input.id = "name"
                break;

            case 1:
                textSpan.textContent = "purpose";
                input.name="purpose";
                input.placeholder="10";
                input.type="number";
                input.id = "purpose"
                break;

            case 2:
                textSpan.textContent = "url";
                input.name="url";
                input.placeholder="www.coolbot.com";
                input.type="text_input";
                input.id = "url"
                break;

            case 3:
                textSpan.textContent = "version";
                input.name="version";
                input.placeholder="100";
                input.type="number";
                input.id = "version"
                break;

            case 4:
                textSpan.textContent = "license";
                input.name="license";
                input.placeholder="1990-01-01";
                input.type="text_input";
                input.id = "license"
                break;

        }

        console.log("input:", input);
        label.appendChild(input);

        

    }
        document.getElementById("form").appendChild(formInsert);

        let names = document.getElementsByClassName("name");
        let maxWidth = 0;

        for (let i = 0; i < names.length; i++) {
            console.log("names: " + names[i].offsetWidth);
            if (names[i].offsetWidth > maxWidth) {
                maxWidth = names[i].offsetWidth;
            }
        }

        for (let i = 0; i < names.length; i++) {
            names[i].style.width = maxWidth + "px";
        }


    let submit = document.createElement("input");
    submit.className = "submit";
    submit.value = "Submit";
    submit.type = "submit";
    submit.action = "/insert";
    fieldset.appendChild(submit);

    
}

function edit(id, name, purpose, url, version, license) {
    let formEdit = document.createElement("form");
    let results = document.getElementById("results")
    let add = document.getElementById("add")
    
    if (formOld) {
        formOld.parentNode.removeChild(formOld);
    }
    
    formEdit.id = "formOld";
    formEdit.action = "/safe-update";
    formEdit.method = "get";

    add.appendChild(formEdit);

    let fieldset = document.createElement("fieldset");
    formEdit.appendChild(fieldset);

    let legend = document.createElement("legend");
    fieldset.appendChild(legend);
    legend.innerHTML = "edit";

    for (let i = 0; i < 5; i++) {
        let label = document.createElement("label");
        fieldset.appendChild(label);

        let input = document.createElement("input");
        input.size=20;
        input.maxlength=50;
        
        let textSpan = document.createElement("span");
        textSpan.className = "name";
        label.appendChild(textSpan);


        let decSpan = document.createElement("span");
        decSpan.innerHTML = " ⇢ ";
        decSpan.textContent = " ⇢ ";
        label.appendChild(decSpan);

        switch (i) {
            case 0:
                textSpan.textContent = "name";
                input.name="name";
                input.value=name;
                input.type="text_input";
                input.id="name"
                break;

            case 1:
                textSpan.textContent = "purpose";
                input.name="purpose";
                input.value=purpose;
                input.type="text_input";
                input.id="purpose"
                break;

            case 2:
                textSpan.textContent = "url";
                input.name="url";
                input.value=url;
                input.type="text_input";
                input.id="url"
                break;

            case 3:
                textSpan.textContent = "version";
                input.name="version";
                input.value=version;
                input.type="text_input";
                input.id="version"
                break;

            case 4:
                textSpan.textContent = "license";
                input.name="license";
                input.value=license;
                input.type="text_input";
                input.id="license"
                break;

        }
        label.appendChild(input);
    }

    let names = document.getElementsByClassName("name");
    let maxWidth = 0;

    for (let i = 0; i < names.length; i++) {
        console.log("names: " + names[i].offsetWidth);
        if (names[i].offsetWidth > maxWidth) {
            maxWidth = names[i].offsetWidth;
        }
    }

    for (let i = 0; i < names.length; i++) {
        names[i].style.width = maxWidth + "px";
    }

    // hidden row id
    let buttonHidden = document.createElement("input");
    buttonHidden.name = "id";
    buttonHidden.value = id;
    buttonHidden.type = "hidden";
    buttonHidden.className = "hidden";

    // add hidden row id to buttons
    fieldset.appendChild(buttonHidden);

    let formData = document.getElementById("formOld");
    let data = new FormData(formData);
    let submit = document.createElement("input");
    submit.className = "submit";
    submit.value = "Submit";
    submit.type = "submit";
    submit.id = "submit";
    submit.action = "/safe-update";
    fieldset.appendChild(submit);

    submit.addEventListener('click', function(event){;
        let userName = document.getElementById("name").value;
        let userpurpose = document.getElementById("purpose").value;
        let userurl = document.getElementById("url").value;
        let userversion = document.getElementById("version").value;
        let userlicense = document.getElementById("license").value;

        event.preventDefault();
        var req = new XMLHttpRequest();
        console.log("userurl: " + userurl);

        req.open('GET', '/safe-update?id=' + buttonHidden.value + "&name=" + userName + "&purpose=" + userpurpose + "&url=" + userurl + "&userversion=" + userversion + "&license=" + userlicense, true);

        req.onload = function() {
            let res = req.responseText;
            window.location.href = '/';
        }

        req.send(null);
    });

}



// create table with given number of rows and columns
function tabler() {
    let fields = "Header";
    let headCount = 1;

    let jsonData = document.getElementById("results").innerHTML;
    jsonData = JSON.parse(jsonData);
    console.log("jsonData:", jsonData);

    // generate table
    let table = document.createElement("table");
    table.id = "myTable";
    let tableHead = document.createElement("tr");
    
    // generate header
    //while (headCount <= col) {
    let jsonObject = jsonData[0];
    for (let n in jsonObject) {
        if (n != "id") {
            let tableHeadCell = document.createElement("th");
            tableHeadCell.textContent = n;
            tableHead.appendChild(tableHeadCell);
        }
    }


    // append table
    table.appendChild(tableHead);
    table.style.borderSpacing = "0em";

    rows(jsonData, table);

    return table;
}


function rows(jsonData, table)
{
    let rowCount = 1;
    let colCount = 1;

    // create rows
    for (let i = 0; i < jsonData.length; i++) {
        let tableRow = document.createElement("tr");
        //tableRow.style.backgroundColor = "lavender";

        // create cells in rows
        let jsonObject = jsonData[i];
        console.log("jsonObject:", jsonObject);
        for (let n in jsonObject) {

            if (n != "id") {
                let cell = document.createElement("td");
                cell.textContent = jsonObject[n];
                tableRow.appendChild(cell);
                colCount += 1;
            }
        }

        // add row to table
        table.appendChild(tableRow);

        // cell to hold edit and delte buttons
        let cell = document.createElement("td");
        tableRow.appendChild(cell);

        // edit form and button
        let formEdit = document.createElement("form");
        //formEdit.action = "/safe-update";
        formEdit.action = "/edit";
        formEdit.method = "get";
        cell.appendChild(formEdit);

        let buttonEdit = document.createElement("input");
        buttonEdit.value = "Edit";
        buttonEdit.type = "submit";
        buttonEdit.className = "buttonEdit";
        formEdit.appendChild(buttonEdit);


        // delete form and button
        let formDelete = document.createElement("form");
        formDelete.action = "/delete";
        formDelete.method = "get";
        cell.appendChild(formDelete);

        let buttonDelete = document.createElement("input");
        buttonDelete.value = "Delete";
        buttonDelete.type = "submit";
        buttonDelete.className = "buttonDelete";
        formDelete.appendChild(buttonDelete);

        // hidden row id
        let buttonHidden = document.createElement("input");
        buttonHidden.name = "id";
        buttonHidden.value = jsonObject.id;
        console.log("jsonObject.id:", jsonObject.id);
        buttonHidden.type = "hidden";
        buttonHidden.className = "hidden";
        
        // add hidden row id to buttons
        formDelete.appendChild(buttonHidden);
        formEdit.appendChild(buttonHidden.cloneNode(true));
    };
}


// create table and selection
let table = document.querySelector("#table")
table.appendChild(tabler());

let formOld = document.createElement("form");
formOld.id = "formOld";
table.appendChild(formOld);

let results = document.getElementById("results")
let editRow = JSON.parse(results.innerHTML);
for (let i = 0; i < editRow.length; i++)
{
    for (let n in editRow[i])
    {
        if (n == "id") {
            var id = editRow[i][n];
        }
        if (n == "name") {
            var name = editRow[i][n];
        }
        else if (n == "purpose") {
            var purpose = editRow[i][n];
        }
        else if (n == "url") {
            var url = editRow[i][n];
        }
        else if (n == "version") {
            var version = editRow[i][n];
        }
        else if (n == "license") {
            var license = editRow[i][n];
        }
    }
}

edit(id, name, purpose, url, version, license);
